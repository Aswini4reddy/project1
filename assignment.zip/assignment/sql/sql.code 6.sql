SELECT *
FROM order_region_a
WHERE critical_column1 IS NULL OR critical_column2 IS NULL;

-- Example: Check for duplicate records in order_region_b
SELECT column1, column2, COUNT(*)
FROM order_region_b
GROUP BY column1, column2
HAVING COUNT(*) > 1;


