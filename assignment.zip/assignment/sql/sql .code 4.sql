DELETE FROM your_table_name
WHERE OrderId IN (
    SELECT OrderId
    FROM (
        SELECT OrderId,
               ROW_NUMBER() OVER (PARTITION BY OrderId ORDER BY OrderId) AS RowNumber
        FROM your_table_name
    ) AS t
    WHERE RowNumber > 1
);

