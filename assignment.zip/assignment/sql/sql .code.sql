
   import pandas as pd
import sqlite3

# Sample data for Region A
data_region_a = [
    {'OrderId': 1, 'OrderItemId': 101, 'QuantityOrdered': 2, 'ItemPrice': 10.0, 'PromotionDiscount': 1.0},
    {'OrderId': 2, 'OrderItemId': 102, 'QuantityOrdered': 1, 'ItemPrice': 20.0, 'PromotionDiscount': 2.0},
]

# Sample data for Region B
data_region_b = [
    {'OrderId': 3, 'OrderItemId': 201, 'QuantityOrdered': 4, 'ItemPrice': 15.0, 'PromotionDiscount': 1.5},
    {'OrderId': 2, 'OrderItemId': 202, 'QuantityOrdered': 2, 'ItemPrice': 25.0, 'PromotionDiscount': 3.0},  # Duplicate OrderId
]

# Convert to DataFrames
df_a = pd.DataFrame(data_region_a)
df_b = pd.DataFrame(data_region_b)

# Add region column
df_a['region'] = 'A'
df_b['region'] = 'B'

# Combine the data
combined_df = pd.concat([df_a, df_b], ignore_index=True)

# Calculate total_sales
combined_df['total_sales'] = combined_df['QuantityOrdered'] * combined_df['ItemPrice']

# Remove duplicates based on OrderId, keeping the first occurrence
combined_df = combined_df.drop_duplicates(subset='OrderId', keep='first')

# Connect to SQLite database
conn = sqlite3.connect('sales.db')
cursor = conn.cursor()

# Create table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS sales (
        OrderId INTEGER PRIMARY KEY,
        OrderItemId INTEGER,
        QuantityOrdered INTEGER,
        ItemPrice REAL,
        PromotionDiscount REAL,
        region TEXT,
        total_sales REAL
    )
''')

# Insert data into the table
combined_df.to_sql('sales', conn, if_exists='replace', index=False)

# Commit the transaction and close the connection
conn.commit()
conn.close()

print("Data successfully loaded into the SQLite database.")










