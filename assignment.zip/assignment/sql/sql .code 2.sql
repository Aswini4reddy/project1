ALTER TABLE your_table_name
ADD COLUMN total_sales DECIMAL(10, 2);

-- Update the total_sales column with the calculated values
UPDATE your_table_name
SET total_sales = QuantityOrdered * ItemPrice;