CREATE TABLE combined_orders (
    OrderId INT,
    OrderItemId INT,
    QuantityOrdered INT,
    ItemPrice DECIMAL(10, 2),
    PromotionDiscount DECIMAL(10, 2)
);

