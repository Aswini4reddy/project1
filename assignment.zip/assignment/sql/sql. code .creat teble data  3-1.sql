CREATE TABLE sales_data (
    id INTEGER PRIMARY KEY,
    region TEXT,
    sales_amount REAL,
    transaction_date DATE
);
