CREATE TABLE transformed_data (
    OrderId INTEGER PRIMARY KEY,
    OrderItemId INTEGER,
    QuantityOrdered INTEGER,
    ItemPrice DECIMAL(10, 2),
    PromotionDiscount DECIMAL(10, 2),
    TotalSales DECIMAL(10, 2),
    Region CHAR(1)
);
INSERT INTO transformed_data (OrderId, OrderItemId, QuantityOrdered, ItemPrice, PromotionDiscount, TotalSales, Region)


