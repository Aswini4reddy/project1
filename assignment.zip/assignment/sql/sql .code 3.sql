ALTER TABLE combined_orders
ADD COLUMN total_sales DECIMAL(10, 2);

-- Update the total_sales column with the calculated values
UPDATE combined_orders
SET total_sales = QuantityOrdered * ItemPrice;select * from sakila.actor;
