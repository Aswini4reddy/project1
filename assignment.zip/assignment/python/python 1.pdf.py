Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import pandas as pd

def extract_data(region_a_file, region_b_file):
    try:
        # Read data from the provided Excel files
        region_a_data = pd.read_excel(region_a_file)
        region_b_data = pd.read_excel(region_b_file)
        
        return region_a_data, region_b_data
    
    except Exception as e:
        print("An error occurred while reading the data:", e)
        return None, None