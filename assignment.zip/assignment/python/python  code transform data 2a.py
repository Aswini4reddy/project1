Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import pandas as pd

def transform_data(region_a_file, region_b_file):
    # Read data from both region files
    region_a_data = pd.read_excel(region_a_file)
    region_b_data = pd.read_excel(region_b_file)

    # Add a column for region
    region_a_data['region'] = 'A'
    region_b_data['region'] = 'B'

    # Concatenate data from both regions
    combined_data = pd.concat([region_a_data, region_b_data], ignore_index=True)

    # Calculate total_sales
    combined_data['total_sales'] = combined_data['QuantityOrdered'] * combined_data['ItemPrice']

    # Drop duplicates based on OrderId
    combined_data.drop_duplicates(subset=['OrderId'], keep='first', inplace=True)

    return combined_data